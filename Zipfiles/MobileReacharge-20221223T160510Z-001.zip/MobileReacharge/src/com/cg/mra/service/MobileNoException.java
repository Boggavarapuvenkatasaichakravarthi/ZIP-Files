package com.cg.mra.service;

public class MobileNoException extends Exception {
public MobileNoException(String msg){
	System.out.println(msg);
}
}
