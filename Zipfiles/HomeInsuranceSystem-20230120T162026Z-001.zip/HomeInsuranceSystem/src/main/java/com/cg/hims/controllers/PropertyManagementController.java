package com.cg.hims.controllers;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hims.exceptions.PropertyNotFoundException;
import com.cg.hims.entities.Property;

import com.cg.hims.service.IPropertyServiceImpl;


/*Controller Class for Property Management
 * Author:NEHA DEY
 * Date:16-05-2021*/


@RestController
@RequestMapping("/property")
public class PropertyManagementController {
	@Autowired
	IPropertyServiceImpl propertyimpl;   /*service layer object autowired*/
	
	
	/*****************************************************
	 * Method:addProperty
	 * Description:It is used to add Property to Propertytable
	 * @param property:property's reference variable
	 * @returns property:It returns property details
	 * @postMapping:It is used to handle the HTTP Post requests matched with given URI Expression
	 * @RequestBody:It is used to bind the HTTP request /response body with a domain object 
	 *   in method parameter or return type
	 ***************************************************************************************************************************/
	
	@PostMapping("/addProperty")
	public ResponseEntity<Property> addProperty(@RequestBody Property property) {
		
		if(property.getProperty_id()==0)
			return new ResponseEntity("Property empty",HttpStatus.NOT_FOUND);
		System.out.println("Property added ");
		Property pro=propertyimpl.addProperty(property);
		return new ResponseEntity<Property>(property,HttpStatus.OK);
	}
	
	/***************************************
	 * Method:showAllProperty
	 * Description:It is used to show Property to propertytable
	 * @param property:property's reference variable
	 * @returns property:It returns all property details
	 * @GetMapping:It is used to handle the HTTP get requests matched with given URI Expression
	 * @RequestBody:It is used to bind the HTTP request /response body with a domain object 
	 *   in method parameter or return type
	 ***************************************************************************************************************************/
	
	@GetMapping("/ViewAllProperty")
	public ResponseEntity<List<Property>> showAllProperty(){
		List<Property>property=propertyimpl.viewAllProperty();
		if(property.isEmpty())
			return new ResponseEntity("Property Not Found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Property>>(property,HttpStatus.OK);
	}
	
	/***************************************
	 * Method:findPropertyById
	 * Description:It is used to view property of a given id
	 * @PathVariable: extract values from the URI path
	 * @returns propertyimpl:It returns property by id
	 * @GetMapping:It is used to handle the HTTP GET requests matched with given URI Expression
	 * @RequestBody:It is used to bind the HTTP request /response body with a domain object 
	 *    in method parameter or return type
	 ***************************************************************************************************************************/
	@GetMapping("/ViewPropertyById/{id}")
	public Optional<Property> findPropertyById(@PathVariable("id")int id) throws PropertyNotFoundException
	{
		return propertyimpl.findPropertyByid(id);
	}
	
	/***************************************
	 * Method:updateProperty
	 * Description:It is used to update property 
	 * @param property:property's reference variable
	 * @returns property:It returns HTTP status
	 * @putMapping:It is used to handle the HTTP PUT requests matched with given URI Expression
	 * @RequestBody:It is used to bind the HTTP request /response body with a domain object 
	 *  in method parameter or return type
	 ***************************************************************************************************************************/
	@PutMapping("/updateProperty")
	public ResponseEntity<Property> updateProperty(@RequestBody Property property) throws PropertyNotFoundException
	{
		if(property==null)
			return new ResponseEntity("enter the proper property to be updated:",HttpStatus.NOT_FOUND);
		return new ResponseEntity<Property>(propertyimpl.updateProperty(property),HttpStatus.OK);
	}
	
	/***************************************
	 * Method:DeleteProperty
	 * Description:It is used to delete a property from propertytable
	 * @returns propertyimpl.RemoveProperty(id):It returns propertyimpl object.
	 * @PathVariable: extract values from the URI path
	 * @postMapping:It is used to handle the HTTP Delete requests matched with given URI Expression
	 * @RequestBody:It is used to bind the HTTP request /response body with a domain object in method parameter or return type
	 ***************************************************************************************************************************/
	
	@DeleteMapping("/DeleteProperty/{id}")
	public String DeleteProperty(@PathVariable("id")int id) throws PropertyNotFoundException
{
		return propertyimpl.RemoveProperty(id);
}
}
