package com.cg.hims.exceptions;

public class QuoteNotFoundException extends Exception {
	
	public QuoteNotFoundException() {
		
	}
	public QuoteNotFoundException(String s){
		super(s);
	}
}
