package com.cg.hims.exceptions;

public class PropertyNotFoundException extends Exception{
	public PropertyNotFoundException(String s) {
		super(s);
	}
}
