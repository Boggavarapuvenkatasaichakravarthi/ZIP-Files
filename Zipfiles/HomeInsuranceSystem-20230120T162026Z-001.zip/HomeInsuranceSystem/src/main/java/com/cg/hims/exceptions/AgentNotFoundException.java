package com.cg.hims.exceptions;

public class AgentNotFoundException extends Exception {

	public AgentNotFoundException(String string) {
		super(string);
	}
}
