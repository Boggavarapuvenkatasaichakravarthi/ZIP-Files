package com.cg.hims.service;

import java.util.List;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hims.exceptions.PropertyNotFoundException;
import com.cg.hims.entities.Agent;
import com.cg.hims.entities.Property;
import com.cg.hims.repository.IAgentRepository;
import com.cg.hims.repository.IPropertyRepository;

/*
 * Author : NEHA DEY
 * Date : 16-05-2021
 * Description : Property Service Implementation
*/

@Service
@Transactional
public class IPropertyServiceImpl implements IPropertyService {

	@Autowired
	IPropertyRepository propertyDao; // repository object (autowired)
	
	@Autowired
	IAgentRepository agentDao;

	/****************************************************************************
	 * Method: addPolicy Description: It is used to add Policy into Policy table
	 * 
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations. 
	 * Created By- NEHA DEY 
	 * Created Date -16-05-2021
	 *****************************************************************************/
	@Override
	public Property addProperty(Property property) {
		// TODO Auto-generated method stub
		propertyDao.save(property);
		return property;
	}

	/*****************************************************************************
	 * Method: updatePolicy Description: It is used to update Policies into Policy
	 * table
	 * 
	 * @return Policy: It returns Policy with details
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations. 
	 *Created By- NEHA DEY 
	 *Created Date -16-05-2021
	 ********************************************************************************/

	@Override
	public Property updateProperty(Property property) throws PropertyNotFoundException {

		if (!propertyDao.existsById(property.getProperty_id()))
			throw new PropertyNotFoundException("No Properties available");
		propertyDao.save(property);
		return property;
	}

	/**********************************************************************
	 * Method: findPropertyByid Description: It is used to view property by
	 * propertyid from Property table
	 * 
	 * @return PropertyDao.findById(id): It returns the property of given ID.
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations.
	 * Created By- NEHA DEY 
	 * Date -16-05-2021
	 *****************************************************************************/
	@Override
	public Optional<Property> findPropertyByid(int id) throws PropertyNotFoundException {

		// TODO Auto-generated method stub
		if (!propertyDao.existsById(id))
			throw new PropertyNotFoundException("Property not found");

		return propertyDao.findById(id);
	}

	/********************************************************************************
	 * Method: removeProperty Description: It is used to remove/Delete a property
	 * from Property Table
	 * 
	 * @return : Returns String.
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations. 
	 *Created By-NEHA DEY 
	 * Date 16-05-2021
	 *******************************************************************************/

	@Override
	public String RemoveProperty(int id) throws PropertyNotFoundException {

		// TODO Auto-generated method stub
		if (!propertyDao.existsById(id))
			throw new PropertyNotFoundException("Property Not Found!");

		propertyDao.deleteById(id);
		return "Successfully Deleted";
	}

	/**************************************************************************
	 * Method: ViewAllProperty Description: It is used to view all the property
	 * 
	 * @return : Returns List of Property in Database.
	 * @Override: It is used to override the JpaRepository methods for performing
	 *            CURD operations. 
	 *Created By-NEHA DEY 
	 *Date 16-05-2021
	 *****************************************************************************/
	@Override
	public List<Property> viewAllProperty() {
		// TODO Auto-generated method stub
		List<Property> propertyList = propertyDao.findAll();
		return propertyList;
	}
	
	public List<Property> viewProperty(int id) {
		Optional<Agent> agent=agentDao.findById(id);
		return propertyDao.findAllByAgent(agent);
	}

}
