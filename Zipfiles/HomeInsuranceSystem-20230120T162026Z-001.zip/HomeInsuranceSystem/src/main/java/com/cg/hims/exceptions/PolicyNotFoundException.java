package com.cg.hims.exceptions;

public class PolicyNotFoundException extends Exception {

	public PolicyNotFoundException(String m) {
		super(m);
	}
}
