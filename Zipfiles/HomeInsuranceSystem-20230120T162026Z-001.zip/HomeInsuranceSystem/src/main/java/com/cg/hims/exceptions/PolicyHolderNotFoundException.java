package com.cg.hims.exceptions;

public class PolicyHolderNotFoundException extends Exception {
		
	public PolicyHolderNotFoundException(String s){
			super(s);
		}
	
}
