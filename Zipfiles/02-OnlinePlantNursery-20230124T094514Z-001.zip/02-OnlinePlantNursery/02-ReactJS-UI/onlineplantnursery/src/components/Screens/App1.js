import Home from "../Home";
import React from "react";
import Navbar from "../Navbar/navbar";


const App1 = () => {
  return (
    <>
   <Navbar/>
      <Home />
    </>
  );
};

export default App1;
