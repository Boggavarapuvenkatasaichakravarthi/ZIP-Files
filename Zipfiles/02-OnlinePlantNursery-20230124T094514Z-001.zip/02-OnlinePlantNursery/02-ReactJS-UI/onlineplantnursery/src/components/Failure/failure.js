import React from "react";

const Failure = () => {
  return (
    <div style={{backgroundImage:URL('./bgimg.jpg')}}>
      <h1>Invalid Login Credentials</h1>
    </div>
  );
};

export default Failure;
