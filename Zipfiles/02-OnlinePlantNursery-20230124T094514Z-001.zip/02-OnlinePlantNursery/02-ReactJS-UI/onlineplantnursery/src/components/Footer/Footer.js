import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <div className="footer mt-4">
      <div className="socialMedia">
      </div>
      <p> Capgemini &copy; 2022 Plant Nursery</p>
    
    </div>
  );
}

export default Footer;