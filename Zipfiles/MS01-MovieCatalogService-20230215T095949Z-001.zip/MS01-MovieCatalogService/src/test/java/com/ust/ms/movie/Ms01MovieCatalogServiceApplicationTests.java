package com.ust.ms.movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ms01MovieCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
